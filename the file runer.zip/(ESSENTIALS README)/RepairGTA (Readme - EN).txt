  __  __ _      __  __           _     
 |  \/  (_)    |  \/  |         | | 2022
 | \  / |___  _| \  / | ___   __| |___ 
 | |\/| | \ \/ / |\/| |/ _ \ / _` / __|
 | |  | | |>  <| |  | | (_) | (_| \__ \
 |_|  |_|_/_/\_\_|  |_|\___/ \__,_|___/
                                       

=======   MixMods.com.br   ======= - Best visualization with monospaced fonts, like "Consolas".


------- Instructions:

Extract the folder "RepairGTA" to your Modloader folder.

-- Essentials Pack download: https://www.mixmods.com.br/2019/06/sa-essentials-pack/


 = Current features:
- Fixes bugs when installing and uninstalling mods that add enex (yellow cones on doors), which caused CJ to be sent to incorrect locations (only prevents future issues, not already present ones).
- Automatically erases all duplicate icons (blips) on the radar (sames, in the same position).
- Automatically erases all duplicate car generators (parked vehicles) (sames, in the same position).
- Automatically deletes all saved objects with non-existent models (eg, uninstalled mods, causing crash).
- You can delete nearby blips manually.
- Fixes made are noted in a .log file at mod folder and fixed in your saved game (when you save it again).


= Fix for interiors:
Fixing buggy "enex" only fixes future problems,
so if your save game has this bug, it won't fix it, remove the mods, save the game and install this mod,
always have this mod installed for your game to work better.


= How to delete nearby blips (map icons) manually:
This function was created thinking about deleting blips from mods that were stuck in the save game (which were not created with CLEO+) even after deleting the mod.
Type "DELBLIP" to manually erase the blip closest to the current position of the CJ.
It only removes if it is very close (around 5 meters).
You can literally erase any blip from the game, be careful with that!
 

Version: Build 5
--------------------

Author: Junior_Djjr


====   MixMods.com.br                ====
====   fb.com/FamiliaMixMods         ====
====   youtube.com/JuniorDjjrMixMods ====

