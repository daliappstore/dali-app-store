  __  __ _      __  __           _     
 |  \/  (_)    |  \/  |         | | 2018
 | \  / |___  _| \  / | ___   __| |___ 
 | |\/| | \ \/ / |\/| |/ _ \ / _` / __|
 | |  | | |>  <| |  | | (_) | (_| \__ \
 |_|  |_|_/_/\_\_|  |_|\___/ \__,_|___/
                                       

=======   MixMods.com.br   ======= - Best visualization in Notepad with monospaced font, as "Consolas".


------- Instructions:

Extract the .asi file to your GTA directory.
(also work with other games using Ultimate ASI Loader)

-- Download the latest version of Modloader: MixMods.com.br/2015/01/SA-Modloader.html



Note: Some anti-virus may accuse of viruses because you are removing a Windows security that doesn't let mods do such things on game. It's normal.
������� If the problem still isn't solved, try restarting the PC and / or turning off DEP manually on the control panel and restarting.



Version: Renamed file
--------------------

Author: Fabio


====   MixMods.com.br         ====
====   fb.com/FamiliaMixMods  ====

