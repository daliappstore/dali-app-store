  __  __ _      __  __           _     
 |  \/  (_)    |  \/  |         | | 2023
 | \  / |___  _| \  / | ___   __| |___ 
 | |\/| | \ \/ / |\/| |/ _ \ / _` / __|
 | |  | | |>  <| |  | | (_) | (_| \__ \
 |_|  |_|_/_/\_\_|  |_|\___/ \__,_|___/
                                       

=======   MixMods.com.br   ======= - Best visualization with monospaced fonts, like "Consolas".


------- Instructions:

Extract everything to the folder where your GTA SA is installed.

Attention: If you are installing a very large total conversion mod, you may need to delete "CLEO+.cleo".

Only for gta_sa.exe 1.0 US. If Steam/RLG, downgrade it: https://www.mixmods.com.br/2021/09/primeiros-passos-para-montar-um-gta-modificado/#downgrade


-- INCLUDED:
CLEO Library (v4.4.4; without dev files): MixMods.com.br/2014/02/Livraria-CLEO.html
CLEO+ (v1.1.4; without dev files): MixMods.com.br/2020/03/CLEOPlus.html 
Silent's ASI Loader (v1.3; without "scripts" folder): MixMods.com.br/2013/02/silent-asi-loader.html


-- How to install CLEO mods:
The CLEO mods (.cs files among others) can be installed in "CLEO" folder or inside modloader.
When installing a CLEO mod in ModLoader, prefer to include it in a subfolder named "CLEO", for example "modloader/mod/CLEO"
Always read the Readme file that comes with each mod download.


--------------------

CLEO 1, 2, 3, 4.3 and 4.4: Seemann
CLEO 4 and 4.1: Alien
CLEO 4.3: Deji
CLEO 4.4: Junior_Djjr, MiranDMC

Thanks to:
Listener (for his great work in exploration of the GTA series)
NTAuthority, LINK/2012, DK22Pac, Fabio, Nex' (for additional support with CLEO 4.3)
mfisto (alpha-testing of CLEO 4, his support and advices)

CLEO+: Junior_Djjr
Silent's ASI Loader: Silent, NTAuthority
bass.dll: Un4seen


====   MixMods.com.br                ====
====   fb.com/FamiliaMixMods         ====
====   youtube.com/JuniorDjjrMixMods ====
