  __  __ _      __  __           _     
 |  \/  (_)    |  \/  |         | | 2025
 | \  / |___  _| \  / | ___   __| |___ 
 | |\/| | \ \/ / |\/| |/ _ \ / _` / __|
 | |  | | |>  <| |  | | (_) | (_| \__ \
 |_|  |_|_/_/\_\_|  |_|\___/ \__,_|___/
                                       

=======   MixMods.com.br   ======= - Best visualization in Notepad with monospaced font, as "Consolas".


------- Instructions:

Extract the files to any folder inside Modloader folder. Or if you prefer to your "Scripts" folder or GTA SA directory.

-- Download the latest version of Modloader: MixMods.com.br/2015/01/SA-Modloader.html



 You can edit .ini file to configure things like hud size, force resolution, control fov etc.

 FOV changing with car speed (for speed sensation) has been removed, now available in a separate CLEO mod: https://www.mixmods.com.br/2021/05/widescreen-fix-para-gta-sa-corrigir-widescreen/

 If you DO NOT use widescreen loadscreens mod (https://www.mixmods.com.br/2021/12/loadscreens-4k-definitive-artworks-widescreen-hd/), set "FrontendAspectRatio = auto" in .ini.

 You can enable other fixes with "EnableSCMDrawingFixes=1" but this will break numerous CLEO mods that draw things on the screen (not recommended).



Version: Nov 29, 2024 (Unofficial)
--------------------

Author: ThirteenAG
Unofficial improvements: niresh1234

====   MixMods.com.br         ====
====   fb.com/FamiliaMixMods  ====

