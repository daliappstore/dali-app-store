  __  __ _      __  __           _     
 |  \/  (_)    |  \/  |         | | 2024
 | \  / |___  _| \  / | ___   __| |___ 
 | |\/| | \ \/ / |\/| |/ _ \ / _` / __|
 | |  | | |>  <| |  | | (_) | (_| \__ \
 |_|  |_|_/_/\_\_|  |_|\___/ \__,_|___/
                                       

=======   MixMods.com.br   ======= - Best visualization with monospaced font, as "Consolas".


------- Instructions:

Extract the "SilentPatch" folder to your Modloader folder. Or if you prefer to your GTA SA directory, or "scripts" folder.

Note: This mod is already included on Essentials Pack: https://www.mixmods.com.br/2019/06/sa-essentials-pack/

-- Download the latest version of Modloader: https://www.mixmods.com.br/2018/01/modloader/



 Inside .ini there are several informations and stuffs that you may want to enable/disable.

 Remember that Maverick and Skimmer comes with disabled rotor blur by default in .ini file, because the original model comes with bugged textures and doesn't work. Remove them from .ini if you use some mod that fixes (like Proper Fixes https://www.mixmods.com.br/2024/02/sa-proper-fixes/ )

 Full list of functions in english on "Readme (ORIGINAL).txt".
 Read "Readme (ORIGINAL).txt" if you want to install on Steam or RGL (Rockstar Games Launcher) version.
 


Version: v1.1 Build 33
--------------------

Author: Silent

Credits:
	aap
	DK22Pac
	Fire_Head
	Nick007J
	NTAuthority
	Sergenaur
	spaceeinstein
	Wesser

Thanks to:
	Ash_735
	Blackbird88
	gamerzworld
	iFarbod
	Inadequate
	LonesomeRider
	mirh
	Reyks
	Tomasak


====   MixMods.com.br                ====
====   fb.com/FamiliaMixMods         ====
====   youtube.com/JuniorDjjrMixMods ====

