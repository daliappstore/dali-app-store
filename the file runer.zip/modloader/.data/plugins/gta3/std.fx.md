gta3.std.fx
=========================================================================
 + __Author__:   LINK/2012 (<dma_2012@hotmail.com>)
 + __Priority__: 48
 + __Game__: III, Vice City, San Andreas

*************************************************************************

__Description__:
 This plugin is responsible for loading standard effects and other generic game textures.
